﻿<?php
switch($weekday){
	case 0: $convertered_weekday = 'ЗА ПОНЕДЕЛНИК';
	break;
	case 1: $convertered_weekday = 'ЗА ВТОРНИК';
	break;
	case 2: $convertered_weekday = 'ЗА СРЯДА';
	break;
	case 3: $convertered_weekday = 'ЗА ЧЕТВЪРТЪК';
	break;
	case 4: $convertered_weekday = 'ЗА ПЕТЪК';
	break;
	case 5: $convertered_weekday = 'ЗА СЪБОТА';
	break;
	case 6: $convertered_weekday = 'ЗА НЕДЕЛЯ';
	break;
}
?>