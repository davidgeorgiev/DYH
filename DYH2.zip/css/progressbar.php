<style>
#progressbar {
	background-color: #837d7c;
	border-radius: 3px; /* (height of inner div) / 2 + padding */
	padding: 3px;
}

#progressbar > div {
	background-color: #d2c9c6;
	width: 40%; /* Adjust with JavaScript */
	height: 20px;
	border-radius: 3px;
	text-align:center;font-size:16px;
	font-weight: normal;
}
</style>