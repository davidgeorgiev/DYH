﻿<?php
	function ConvertClassNumberToWords($class_number){
		switch($class_number){
			case 1: $class_number = 'Първи';
			break;
			case 2: $class_number = 'Втори';
			break;
			case 3: $class_number = 'Трети';
			break;
			case 4: $class_number = 'Четвърти';
			break;
			case 5: $class_number = 'Пети';
			break;
			case 6: $class_number = 'Шести';
			break;
			case 7: $class_number = 'Седми';
			break;
			case 8: $class_number = 'Осми';
			break;
			case 9: $class_number = 'Девети';
			break;
		}
		return $class_number;
	}
?>