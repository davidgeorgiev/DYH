# DYH
Homeworks manager on PHP

This is one of my a web apps that I hope to help to the students' life. It have a simple and useful interface and you can easy plan your future works in school or work.
Web site is here: http://dyh.hostei.com/
