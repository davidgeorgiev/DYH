﻿<?php
	switch($rank_of_subject){
		case 0: $rank_of_subject_with_words = 'Не е зададено нищо.';
		break;
		case 1: $rank_of_subject_with_words = 'Мразя този предмет толкова, че предпочитам да умра отколкото да имам час.';
		break;
		case 2: $rank_of_subject_with_words = 'Мразя този предмет твърде много. Почти винаги имам двойки.';
		break;
		case 3: $rank_of_subject_with_words = 'Мразя този предмет.';
		break;
		case 4: $rank_of_subject_with_words = 'Нито ми харесва да го уча нито ми се отдава. Обикновено имам среден успех.';
		break;
		case 5: $rank_of_subject_with_words = 'Нямам ни най-малко желание да го уча, но щом трябва.';
		break;
		case 6: $rank_of_subject_with_words = 'Нямам особено желание да го уча, но щом трябва.';
		break;
		case 7: $rank_of_subject_with_words = 'Страхотен предмет, но не ми се отдава никак.';
		break;
		case 8: $rank_of_subject_with_words = 'Харесва ми и ми доставя удоволствие да го уча, но нямам толкова висок успех по него.';
		break;
		case 9: $rank_of_subject_with_words = 'Много ми харесва, и имам висок успех по този предмет.';
		break;
		case 10: $rank_of_subject_with_words = 'Толкова ми е любим, че щях да съм на седмото небе ако учехме този предмет и нощем.';
		break;
	}
?>